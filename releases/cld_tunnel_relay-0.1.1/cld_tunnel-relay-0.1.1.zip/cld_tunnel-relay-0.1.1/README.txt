Relay cld_tunnel 0.1.1 (Игра по сети)

Oracle Cloud Free Tier, Ubuntu 24.04, без домена:
1. Скопировать папку на сервер (scp -r).
2. sudo sh install_relay.sh cld_tunnel-relay-0.1.1.jar "" <публичный IP сервера>
3. В консоли Oracle: Networking, VCN, Security List, Add Ingress Rules:
   Source 0.0.0.0/0, TCP, порты 25580 и 25601-25650.
4. В игре: TC Моды, Игра по сети. Адрес relay <IP>:25580, ключ из вывода скрипта.
Лог relay: journalctl -u cld-relay -f
